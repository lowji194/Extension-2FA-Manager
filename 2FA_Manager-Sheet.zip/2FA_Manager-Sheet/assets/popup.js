document.addEventListener('DOMContentLoaded', function () {
  const addButton = document.getElementById('add-twofa-btn');
  const addQrButton = document.getElementById('add-qr-btn');
  const twofaModal = document.getElementById('twofaModal');
  const qrModal = document.getElementById('qrModal');
  const closeModal = document.getElementById('closeModal');
  const closeQrModal = document.getElementById('closeQrModal');
  const scanQrBtn = document.getElementById('scanQrBtn');
  const intervals = {};

  function getCurrentTabWebsite(callback) {
    chrome.tabs.query(
      {
        active: true,
        currentWindow: true,
      },
      (tabs) => {
        let website = 'https://theloi.io.vn/';
        if (tabs[0]) {
          try {
            website = new URL(tabs[0].url).origin;
          } catch (error) {
            console.warn('Invalid URL for current tab, using fallback:', error);
          }
        }
        callback(website);
      }
    );
  }

  addButton.addEventListener('click', () => {
    twofaModal.classList.remove('hidden');
    addButton.classList.add('hidden');
    addQrButton.classList.add('hidden');
    getCurrentTabWebsite((website) => {
      document.getElementById('website').value = website;
    });
  });

  addQrButton.addEventListener('click', () => {
    qrModal.classList.remove('hidden');
    addButton.classList.add('hidden');
    addQrButton.classList.add('hidden');
  });

  closeModal.addEventListener('click', () => {
    twofaModal.classList.add('hidden');
    addButton.classList.remove('hidden');
    addQrButton.classList.remove('hidden');
    document.getElementById('twofa-form').reset();
  });

  closeQrModal.addEventListener('click', () => {
    qrModal.classList.add('hidden');
    addButton.classList.remove('hidden');
    addQrButton.classList.remove('hidden');
    document.getElementById('qrInput').value = '';
  });

  document.getElementById('twofa-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    let website = document.getElementById('website').value.trim();
    let twofa_code = document.getElementById('twofa_code').value.trim();

    twofa_code = twofa_code.toUpperCase();

    console.log('Submitting 2FA form:', { name, website, twofa_code });

    if (!name || !website || !twofa_code) {
      Toastify({
        text: 'Vui lòng điền đầy đủ tất cả các trường',
        duration: 3000,
        close: false,
        gravity: 'top',
        position: 'right',
        style: {
          background: 'red',
          color: 'white',
          padding: '10px 15px',
          borderRadius: '5px',
          boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
        },
      }).showToast();
      return;
    }

    const urlPattern = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/.*)?$/i;
    if (!urlPattern.test(website)) {
      console.log('Website không hợp lệ, thay thế bằng https://theloi.io.vn/');
      website = 'https://theloi.io.vn/';
    }

    const base32Pattern = /^[A-Z2-7]+={0,6}$/;
    if (!base32Pattern.test(twofa_code)) {
      Toastify({
        text: 'Mã 2FA không hợp lệ (phải là Base32: A-Z, 2-7, và có thể có = ở cuối)',
        duration: 3000,
        close: false,
        gravity: 'top',
        position: 'right',
        style: {
          background: 'red',
          color: 'white',
          padding: '10px 15px',
          borderRadius: '5px',
          boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
        },
      }).showToast();
      return;
    }

    const submitBtn = document.querySelector('#twofa-form button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      Đang xử lý...
      <svg class="animate-spin h-5 w-5 text-white inline-block ml-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
    `;

    chrome.runtime.sendMessage(
      { action: 'add2FA', data: { name, website, twofa_code } },
      (response) => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = 'Thêm mã 2FA';

        console.log('Response from background:', response);
        const message = response?.message || 'Đã xảy ra lỗi không xác định';
        const success = response?.success ?? false;

        Toastify({
          text: message,
          duration: 3000,
          close: false,
          gravity: 'top',
          position: 'right',
          style: {
            background: success ? '#2ecc71' : 'red',
            color: 'white',
            padding: '10px 15px',
            borderRadius: '5px',
            boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
          },
        }).showToast();

        if (success) {
          twofaModal.classList.add('hidden');
          addButton.classList.remove('hidden');
          addQrButton.classList.remove('hidden');
          document.getElementById('twofa-form').reset();
          checkAuthorAndFetch();
        }
      }
    );
  });

  scanQrBtn.addEventListener('click', () => {
    const qrInput = document.getElementById('qrInput').value.trim();
    if (!qrInput) {
      Toastify({
        text: 'Vui lòng nhập liên kết QR hoặc Base64',
        duration: 3000,
        style: { background: 'red' },
      }).showToast();
      return;
    }

    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.onload = function () {
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.width = img.width;
      canvas.height = img.height;
      context.drawImage(img, 0, 0, img.width, img.height);
      const imageData = context.getImageData(0, 0, img.width, img.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height);

      if (code) {
        const qrData = code.data;
        processQrData(qrData);
      } else {
        Toastify({
          text: 'Không thể giải mã QR',
          duration: 3000,
          style: { background: 'red' },
        }).showToast();
      }
    };
    img.onerror = function () {
      Toastify({
        text: 'Không thể tải hình ảnh QR',
        duration: 3000,
        style: { background: 'red' },
      }).showToast();
    };

    if (qrInput.startsWith('data:image')) {
      img.src = qrInput;
    } else {
      img.src = qrInput;
    }
  });

  function processQrData(qrData) {
    if (qrData.startsWith('otpauth://totp/')) {
      const url = new URL(qrData.replace('otpauth://', 'http://'));
      const name = decodeURIComponent(url.pathname.substring(1));
      const params = new URLSearchParams(url.search);
      let secret = params.get('secret');
      const issuer = params.get('issuer') || '';

      secret = secret ? secret.toUpperCase() : '';

      if (secret) {
        let displayName = name;
        if (name.includes(':')) {
          displayName = name.split(':')[1];
        }

        document.getElementById('name').value = displayName ? displayName : issuer;
        getCurrentTabWebsite((website) => {
          document.getElementById('website').value = website;
        });
        document.getElementById('twofa_code').value = secret;

        qrModal.classList.add('hidden');
        twofaModal.classList.remove('hidden');
      } else {
        Toastify({
          text: 'Mã QR không chứa khóa bí mật hợp lệ',
          duration: 3000,
          style: { background: 'red' },
        }).showToast();
      }
    } else {
      Toastify({
        text: 'Mã QR không phải định dạng 2FA hợp lệ',
        duration: 3000,
        style: { background: 'red' },
      }).showToast();
    }
  }

  function generateTOTP(twofa_code) {
    const totp = new OTPAuth.TOTP({
      secret: twofa_code,
      algorithm: 'SHA1',
      digits: 6,
      period: 30,
    });
    return totp.generate();
  }

  function getProgressColor(percentage) {
    const rStart = 76;
    const gStart = 175;
    const bStart = 80;
    const rEnd = 244;
    const gEnd = 67;
    const bEnd = 54;

    const r = Math.round(rStart + (rEnd - rStart) * (1 - percentage));
    const g = Math.round(gStart + (gEnd - gStart) * (1 - percentage));
    const b = Math.round(bStart + (bEnd - bStart) * (1 - percentage));

    return `rgb(${r}, ${g}, ${b})`;
  }

  function normalizeUrl(url) {
    let normalized = url.toLowerCase();
    normalized = normalized.replace(/^(https?:\/\/)?(www\.)?/, '');
    normalized = normalized.replace(/\/+$/, '');
    return normalized;
  }

  function extractRootDomain(url) {
    const normalized = normalizeUrl(url);
    const parts = normalized.split('.');
    if (parts.length > 2) {
      return parts.slice(-2).join('.');
    }
    return normalized;
  }

  function areDomainsRelated(domain1, domain2) {
    const root1 = extractRootDomain(domain1);
    const root2 = extractRootDomain(domain2);

    const googleRelatedDomains = ['google.com', 'youtube.com'];

    const isGoogleRelated1 = googleRelatedDomains.includes(root1) || domain1.includes('google');
    const isGoogleRelated2 = googleRelatedDomains.includes(root2) || domain2.includes('google');

    if (isGoogleRelated1 && isGoogleRelated2) {
      return true;
    }

    return root1 === root2 || domain1.includes(root2) || domain2.includes(root1);
  }

  function checkAuthorAndFetch() {
    fetch(chrome.runtime.getURL('manifest.json'))
      .then(response => response.json())
      .then(manifest => {
        const expectedAuthor = 'Lợi Nguyễn';
        if (manifest.author !== expectedAuthor) {
          console.error('Unauthorized extension author:', manifest.author);
          Toastify({
            text: `Lỗi: Tiện ích này không được phép hoạt động. Tác giả phải là "${expectedAuthor}". Vui lòng liên hệ nhà phát triển chính thức.`,
            duration: 5000,
            close: false,
            gravity: 'top',
            position: 'center',
            style: {
              background: '#d32f2f',
              color: 'white',
              padding: '15px 20px',
              borderRadius: '8px',
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
              fontSize: '16px',
              maxWidth: '500px',
              textAlign: 'center',
            },
          }).showToast();
          return;
        }
        fetchTwoFACodes();
      })
      .catch(error => {
        console.error('Error loading manifest.json:', error);
        Toastify({
          text: 'Lỗi: Không thể xác thực tiện ích. Vui lòng thử lại sau hoặc liên hệ nhà phát triển.',
          duration: 5000,
          close: false,
          gravity: 'top',
          position: 'center',
          style: {
            background: '#d32f2f',
            color: 'white',
            padding: '15px 20px',
            borderRadius: '8px',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)',
            fontSize: '16px',
            maxWidth: '500px',
            textAlign: 'center',
          },
        }).showToast();
      });
  }

  function fetchTwoFACodes() {
    Object.keys(intervals).forEach((id) => {
      clearInterval(intervals[id]);
      delete intervals[id];
    });

    getCurrentTabWebsite((currentWebsite) => {
      const normalizedCurrentWebsite = normalizeUrl(currentWebsite);
      const currentRootDomain = extractRootDomain(currentWebsite);
      chrome.storage.sync.get(['tokens'], (result) => {
        let tokens = result.tokens || [];
        const twofaList = document.getElementById('twofa-list');
        let htmlContent = '';

        tokens.sort((a, b) => {
          const normalizedAWebsite = normalizeUrl(a.website);
          const normalizedBWebsite = normalizeUrl(b.website);
          const aMatchesExactly = normalizedAWebsite === normalizedCurrentWebsite;
          const bMatchesExactly = normalizedBWebsite === normalizedCurrentWebsite;
          const aIsRelated = areDomainsRelated(normalizedAWebsite, normalizedCurrentWebsite);
          const bIsRelated = areDomainsRelated(normalizedBWebsite, normalizedCurrentWebsite);

          if (aMatchesExactly && !bMatchesExactly) return -1;
          if (!aMatchesExactly && bMatchesExactly) return 1;

          if (aIsRelated && !bIsRelated) return -1;
          if (!aIsRelated && bIsRelated) return 1;

          return 0;
        });

        if (tokens.length === 0) {
          htmlContent = '<p class="text-center text-gray-400">Chưa có mã 2FA nào.</p>';
        } else {
          tokens.forEach((item) => {
            const logoUrl = `https://www.google.com/s2/favicons?domain=${item.website}&sz=256`;
            let timeLeft = Math.floor(Math.random() * (30 - 10 + 1)) + 10;
            const circleCircumference = 2 * Math.PI * 50;

            let code2fa;
            const base32Pattern = /^[A-Z2-7]+={0,6}$/;
            if (!base32Pattern.test(item.twofa_code)) {
              console.warn(`Invalid Base32 for twofa_code: ${item.twofa_code}`);
              code2fa = 'Invalid';
            } else {
              try {
                code2fa = generateTOTP(item.twofa_code);
              } catch (error) {
                console.error('Error generating TOTP:', error);
                code2fa = 'Error';
              }
            }

            const interval = setInterval(() => {
              const timerElement = document.getElementById(`timer-${item.id}`);
              const timerTextElement = document.getElementById(`timer-text-${item.id}`);
              const codeElement = document.getElementById(`code-${item.id}`);
              const codeDisplayElement = document.getElementById(`code-display-${item.id}`);

              if (!timerElement || !timerTextElement || !codeElement || !codeDisplayElement) {
                clearInterval(interval);
                delete intervals[item.id];
                return;
              }

              if (timeLeft <= 0) {
                timeLeft = 30;
                if (base32Pattern.test(item.twofa_code)) {
                  try {
                    code2fa = generateTOTP(item.twofa_code);
                  } catch (error) {
                    console.error('Error generating TOTP:', error);
                    code2fa = 'Error';
                  }
                } else {
                  code2fa = 'Invalid';
                }
                codeElement.textContent = code2fa;
                codeElement.setAttribute('aria-label', code2fa);
                codeDisplayElement.setAttribute('aria-label', code2fa);
              }

              const circleProgress = circleCircumference * (timeLeft / 30);
              const color = getProgressColor(timeLeft / 30);
              timerElement.style.strokeDashoffset = circleCircumference - circleProgress;
              timerElement.style.stroke = color;
              timerTextElement.textContent = `${timeLeft--}s`;
            }, 1000);

            intervals[item.id] = interval;

            htmlContent += `
              <div class="bg-gray-800 rounded-lg shadow-md p-4 flex justify-between items-center space-x-4 hover:shadow-lg transition">
                <div class="flex items-center space-x-3">
                  <img src="${logoUrl}" alt="Logo" class="w-12 h-12">
                  <div class="flex items-center justify-between w-full">
                    <div>
                      <h4 class="text-lg font-medium text-white">${item.name}
                        <button class="delete-btn text-red-600 ml-2" data-id="${item.id}">
                          <i class="fa-regular fa-trash-can"></i>
                        </button>
                      </h4>
                      <p id="code-display-${item.id}" class="text-sm text-gray-400 copy-text" aria-label="${code2fa}">${item.twofa_code}</p>
                    </div>
                  </div>
                </div>
                <div class="flex flex-col items-center">
                  <p id="code-${item.id}" class="text-lg font-semibold text-white copy-text" aria-label="${code2fa}">${code2fa}</p>
                  <div class="relative">
                    <svg class="w-10 h-10" viewBox="0 0 120 120">
                      <circle cx="60" cy="60" r="50" class="stroke-gray-600" stroke-width="5" fill="none"></circle>
                      <circle cx="60" cy="60" r="50" id="timer-${item.id}" stroke="#4caf50" stroke-width="10" fill="none" stroke-dasharray="314" stroke-dashoffset="0"></circle>
                    </svg>
                    <span id="timer-text-${item.id}" class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-sm">${timeLeft}s</span>
                  </div>
                </div>
              </div>
            `;
          });
        }

        twofaList.innerHTML = htmlContent;

        document.querySelectorAll('.copy-text').forEach((element) => {
          element.addEventListener('click', () => {
            const textToCopy = element.getAttribute('aria-label');
            navigator.clipboard.writeText(textToCopy).then(() => {
              Toastify({
                text: `Đã sao chép: ${textToCopy}`,
                duration: 3000,
                close: false,
                gravity: 'top',
                position: 'right',
                style: {
                  background: '#2ecc71',
                  color: 'white',
                  padding: '10px 15px',
                  borderRadius: '5px',
                  boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
                },
              }).showToast();
            }).catch(() => {
              Toastify({
                text: 'Không thể sao chép mã 2FA',
                duration: 3000,
                close: false,
                gravity: 'top',
                position: 'right',
                style: { background: 'red' },
              }).showToast();
            });
          });
        });

        document.querySelectorAll('.delete-btn').forEach((button) => {
          button.addEventListener('click', () => {
            const itemId = button.getAttribute('data-id');
            const confirmDeleteModal = document.getElementById('confirmDeleteModal');
            const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
            const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');

            confirmDeleteModal.classList.remove('hidden');

            confirmDeleteBtn.onclick = () => {
              confirmDeleteBtn.disabled = true;
              confirmDeleteBtn.innerHTML = `
                Đang xóa...
                <svg class="animate-spin h-5 w-5 text-white inline-block ml-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              `;

              const twofa_code = button.closest('.bg-gray-800').querySelector('.copy-text').textContent;
              chrome.runtime.sendMessage(
                { action: 'delete2FA', data: { id: itemId, twofa_code } },
                (response) => {
                  confirmDeleteBtn.disabled = false;
                  confirmDeleteBtn.innerHTML = 'Xác nhận';

                  const message = response?.message || 'Đã xảy ra lỗi không xác định';
                  const success = response?.success ?? false;

                  Toastify({
                    text: message,
                    duration: 3000,
                    close: false,
                    gravity: 'top',
                    position: 'right',
                    style: {
                      background: success ? '#e74c3c' : 'red',
                      color: 'white',
                      padding: '10px 15px',
                      borderRadius: '5px',
                      boxShadow: '0 2px 10px rgba(0, 0, 0, 0.1)',
                    },
                  }).showToast();

                  if (success) {
                    checkAuthorAndFetch();
                    confirmDeleteModal.classList.add('hidden');
                  }
                }
              );
            };

            cancelDeleteBtn.onclick = () => {
              confirmDeleteModal.classList.add('hidden');
            };
          });
        });
      });
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.tokens) {
      checkAuthorAndFetch();
    }
  });

  checkAuthorAndFetch();
});