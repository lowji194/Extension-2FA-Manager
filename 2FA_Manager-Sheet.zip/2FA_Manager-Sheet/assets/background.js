// Mã bảo mật cố định
const AUTH_KEY = 'KJUZXZANN';
const API_URL = 'https://script.google.com/macros/s/AKfycbyMe8j63uZOn7obPe-MMbY0k7Irr26qKkSAi4_OhDis-Hq0q1sg6rL5jzbCsr6MzscjRw/exec';

// Tạo alarm để đồng bộ dữ liệu 2FA định kỳ mỗi 6 tiếng
chrome.alarms.create('fetch2FAData', {
  periodInMinutes: 360,
});

// Lắng nghe sự kiện alarm để gọi hàm đồng bộ dữ liệu
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'fetch2FAData') {
    fetch2FAData();
  }
});

// Hàm gửi yêu cầu đến Google Apps Script để thêm hoặc xóa mã 2FA
function sendToAppsScript(action, data) {
  console.log(data);

  // Chuẩn bị dữ liệu JSON, thêm auth vào payload
  const payload = action === 'delete' 
    ? { action: 'delete', twofa_code: data.twofa_code, auth: AUTH_KEY } 
    : { ...data, auth: AUTH_KEY };

  return fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
    mode: 'cors',
    redirect: 'follow'
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Phản hồi mạng không ổn định');
      }
      return response.json();
    })
    .then((jsonData) => {
      if (jsonData.status === 'success') {
        return { success: true, message: jsonData.msg };
      } else {
        throw new Error(jsonData.msg || 'Thao tác thất bại');
      }
    })
    .catch((error) => {
      console.error(`Lỗi khi ${action === 'delete' ? 'xóa' : 'thêm'} dữ liệu qua API:`, error);
      throw error;
    });
}

// Hàm đồng bộ dữ liệu 2FA từ Google Apps Script và lưu vào chrome.storage.sync
function fetch2FAData() {
  const urlWithAuth = `${API_URL}?key=${AUTH_KEY}`;

  fetch(urlWithAuth, {
    method: 'GET',
    mode: 'cors',
    redirect: 'follow'
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Phản hồi mạng không ổn định');
      }
      return response.json();
    })
    .then((data) => {
      chrome.storage.sync.get(['tokens'], (result) => {
        let tokens = result.tokens || [];

        // Cập nhật hoặc thêm mới các mã 2FA từ Google Apps Script
        data.forEach((newItem) => {
          const existingItemIndex = tokens.findIndex(
            (token) => token.twofa_code === newItem.twofa_code
          );

          if (existingItemIndex !== -1) {
            tokens[existingItemIndex] = {
              ...tokens[existingItemIndex],
              name: newItem.name,
              website: newItem.website,
              twofa_code: newItem.twofa_code,
            };
          } else {
            tokens.push({
              id: Date.now() + Math.random(),
              name: newItem.name,
              website: newItem.website,
              twofa_code: newItem.twofa_code,
            });
          }
        });

        // Lưu danh sách tokens đã cập nhật vào storage
        chrome.storage.sync.set({ tokens }, () => {
          console.log('Dữ liệu 2FA đã được cập nhật:', tokens);
        });
      });
    })
    .catch((error) => {
      console.error('Lỗi khi lấy dữ liệu từ Google Apps Script:', error);
    });
}

// Lắng nghe tin nhắn từ popup để xử lý thêm hoặc xóa mã 2FA
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // Xử lý yêu cầu thêm mã 2FA
  if (request.action === 'add2FA') {
    const { name, website, twofa_code } = request.data;

    sendToAppsScript('', { name, website, twofa_code })
      .then((result) => {
        chrome.storage.sync.get(['tokens'], (result) => {
          const tokens = result.tokens || [];
          const newToken = {
            id: Date.now() + Math.random(),
            name,
            website,
            twofa_code,
          };
          tokens.push(newToken);

          // Lưu mã 2FA mới vào storage và phản hồi thành công
          chrome.storage.sync.set({ tokens }, () => {
            sendResponse({ success: true, message: 'Đã thêm mã 2FA thành công' });
          });
        });
      })
      .catch((error) => {
        sendResponse({ success: false, message: `Lỗi khi thêm mã 2FA: ${error.message}` });
      });

    return true;
  }

  // Xử lý yêu cầu xóa mã 2FA
  if (request.action === 'delete2FA') {
    const { id, twofa_code } = request.data;

    sendToAppsScript('delete', { twofa_code })
      .then((result) => {
        chrome.storage.sync.get(['tokens'], (result) => {
          const tokens = result.tokens || [];
          const updatedTokens = tokens.filter(
            (token) => String(token.id) !== String(id)
          );

          // Cập nhật storage sau khi xóa và phản hồi thành công
          chrome.storage.sync.set({ tokens: updatedTokens }, () => {
            console.log('Đã xóa mã 2FA khỏi storage:', updatedTokens);
            sendResponse({ success: true, message: 'Đã xóa mã 2FA thành công' });
          });
        });
      })
      .catch((error) => {
        console.error('Lỗi khi xóa mã 2FA:', error);
        sendResponse({ success: false, message: `Lỗi khi xóa mã 2FA: ${error.message}` });
      });

    return true;
  }

  // Phản hồi nếu hành động không hợp lệ
  sendResponse({ success: false, message: 'Hành động không hợp lệ' });
  return false;
});

// Gọi hàm đồng bộ dữ liệu ngay khi background script khởi động
fetch2FAData();